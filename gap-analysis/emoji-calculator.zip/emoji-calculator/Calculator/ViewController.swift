//
//  ViewController.swift
//  Calculator
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var resultLabel: UILabel!
    let emojiNumbers:Array = ["🍆","🅱️","🔥","💯","😂","👏","💩","🍑","👅","😎"]
    var 🔥 = ""
    var 💯 = ""
    var 💩 = ""
    var 👏😂💯💯🔥🔥🔥 = true
    var 💩😂👌 = false
    var 🤡🐪🅱️ = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func otherButtonPress(_ sender: Any) {
    }
    @IBAction func handleButtonPress(_ sender: UIButton) {
        if 🤡🐪🅱️ {
            resultLabel.text = ""
            🤡🐪🅱️ = false
        }
        let currentText = resultLabel.text!
        let textLabel = sender.titleLabel?.text
        if let text = textLabel {
            switch text {
            case "+", "*", "/", "-":
                if 💩😂👌 {
                    return
                }
                💩 = text
                👏😂💯💯🔥🔥🔥 = false
                💩😂👌 = true
                resultLabel.text = "\(currentText) \(💩) "
                break
            case "=":
                👏😂💯💯🔥🔥🔥 = true
                💩😂👌 = false
                🤡🐪🅱️ = true
                let result = calculate()
                resultLabel.text = "\(result)"
                break
            default:
                if 👏😂💯💯🔥🔥🔥 {
                    🔥 = "\(🔥)\(text)"
                } else {
                    💯 = "\(💯)\(text)"
                }
                resultLabel.text = "\(currentText)\(text)"
                break;
            }
        }
    }
    
    func calculate() -> String {
        let firstNumber = getNumber(🍆: 🔥)
        let secondNumber = getNumber(🍆: 💯)
        🔥 = ""
        💯 = ""
        switch 💩 {
        case "+":
            return getEmojis(num: Double(firstNumber + secondNumber))
        case "-":
            return getEmojis(num: Double(firstNumber - secondNumber))
        case "*":
            return getEmojis(num: Double(firstNumber * secondNumber))
        case "/":
            return getEmojis(num: Double(firstNumber / secondNumber))
        default:
            return getEmoji(🍆: 0)
        }
    }
    
    func getNumber(🍆 : String) -> Int {
        var output = ""
        for c in Array(🍆.characters) {
            output += String(emojiNumbers.index(of: String(c))!)
        }
        return Int(output)!
    }
    
    func getEmoji(🍆 : Int) -> String {
        return emojiNumbers[🍆]
    }
    
    func getEmojis(num : Double) -> String {
        let numberAsArray = num.toArray(digits: 2)
        var output = ""
        
        for c in numberAsArray {
            if (String(c) == ".") {
                return output
            }
            else {
                output += getEmoji(🍆: Int(String(c))!)
            }
        }
        
        return output
        
    }
    
}

extension FloatingPoint {
    func toArray(digits: Int) -> Array<Character> {
        return Array(String(format: "%.\(digits)f", self as! CVarArg).characters)
    }
}

